<?php
namespace app\components;


use Yii;
use yii\base\Component;
 
class Menu extends Component{

 	public function ObtenerMenu(){
  		$MenuPrincipal = Yii::$app->db->createCommand('SELECT * FROM menu ORDER BY IdPadre DESC, Orden ASC')->queryAll();

  		return $MenuPrincipal;
 	} 
}
?>