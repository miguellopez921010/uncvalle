$(document).ready(function(){
    $('.bxslider').bxSlider({
      auto: true,
      autoControls: false,
      stopAutoOnClick: true,
      pager: true,
    });

    $('form#formContactenos').submit(function(e){
        e.preventDefault();

        var Datos = $(this).serializeArray();
        //xxxDatos.push({name: 'Mensaje', value: $('textArea#Mensaje')});

        $.ajax({ 
            url: $('#urlBase').val() + '/site/guardar-contactenos',
            type: 'POST',
            data: Datos,
            dataType: 'json',
            beforeSend: function() {
                  $.blockUI({
                            message: '<img src="'+$('#urlBase').val()+'/images/loading.gif" />',
                            css: {
                                'border': 'none',
                                'padding': '15px',
                                'background' : 'none',
                                '-webkit-border-radius': '10px',
                                '-moz-border-radius': '10px',
                                'color': '#fff'
                            }
                        });
                    },          
            success: function(data) {
              if (typeof data == "string"){
                    data = JSON.parse(data);
                }

                if(data.estado == 1){
                    $('#formContactenos')[0].reset();
                }
                alert(data.mensaje);
            },
            error: function() {
                console.log("No se ha podido obtener la información");
                $.unblockUI();
            }
        }).done(function() {
            $.unblockUI();
        });

    });
});

function CargarModal(NombreModal, TipoCargue, Url, Parametros, TituloModal = null, MostrarBotonesFooter = true, MostrarOpcionCerrarSuperior = true) {
    $("#" + NombreModal + '>.modal-dialog>.modal-content>.modal-header>h4.modal-title').html('');
    if (TituloModal != null) {
        $("#" + NombreModal + '>.modal-dialog>.modal-content>.modal-header>h4.modal-title').html(TituloModal);
    }

    $("#" + NombreModal + '>.modal-dialog>.modal-content>.modal-body').html('');
    if (TipoCargue == 1) {
        $("#" + NombreModal + '>.modal-dialog>.modal-content>.modal-body').load($('#urlBase').val() + Url, Parametros);
    } else if (TipoCargue == 2) {
        $("#" + NombreModal + '>.modal-dialog>.modal-content>.modal-body').html(Url);
    }
    
    if(!MostrarBotonesFooter){
        $("#" + NombreModal + '>.modal-dialog>.modal-content>.modal-footer').html('');
    }    
    if(!MostrarOpcionCerrarSuperior){
        $("#" + NombreModal + '>.modal-dialog>.modal-content>.modal-header>button.close').html('');
    }

    $("#" + NombreModal).modal({backdrop: 'static', keyboard: false, show: true});
}

function VerImagenesProducto(IdProducto){
    CargarModal('modalNormal', 1, '/productos/productos/ver-imagenes-producto', {'IdProducto': IdProducto});
}