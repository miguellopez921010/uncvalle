<?php

/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>

<style type="text/css">
    .navbar{
        background-color: #FAFAFA !important;
        /*-webkit-box-shadow: 0px 5px 5px 0px rgba(250,250,250,1);
        -moz-box-shadow: 0px 5px 5px 0px rgba(250,250,250,1);
        box-shadow: 0px 5px 5px 0px rgba(250,250,250,1);*/
        border-bottom: 1px solid #ddd;
    }
    .navbar-brand{
        padding: 0px !important;
        height: auto !important;
    }
    .navbar-toggle{
        border: 1px solid;
        background-color: #cdcdcd !important;
        padding: 14px 12px;
        margin-top: 10px;
    }
    .navbar-toggle>.icon-bar{
        background-color: #000;
    }
    
</style>
<?php

$baseUrl = str_replace('/web', '', (new \yii\web\Request)->getBaseUrl());

/*NavBar::begin([
    'brandLabel' => '<img src="'.Yii::getAlias('@web').'/images/Logo.png" title="'.Yii::$app->params['title'].'" width="120" class="img-responsive">',
    'brandUrl' => $baseUrl,
    'options' => [
        'class' => 'navbar-fixed-top',
    ],
]);
echo Nav::widget([
    'options' => ['class' => 'navbar-nav navbar-right', 'style' => 'padding-top: 8px; padding-bottom: 7px;'],
    'items' => [
        Yii::$app->user->isGuest ? (
            '<li><a class="btn btn-link" onclick="window.location.href=\''.Yii::getAlias('@web').'/site/login\'">Iniciar sesion</a></li>'.''
            //'<li><a class="btn btn-link" onclick="window.location.href=\''.Yii::getAlias('@web').'/site/registrarme\'">Registrar</a></li>'
        ) : (
            '<li><a class="btn btn-link" onclick="window.location.href=\''.Yii::getAlias('@web').'/cuenta/cuenta/mi-cuenta\'">Mi cuenta ('.Yii::$app->user->identity->username.')</a></li>'.
            '<li>'
            . Html::beginForm(['/site/logout'], 'post')
            . Html::submitButton(
                'Cerrar Sesión',
                ['class' => 'btn btn-link logout']
            )
            . Html::endForm()
            . '</li>'
        )
    ],
]);
NavBar::end();*/
?>


<?php 
use app\components\Menu;

$Menu = new Menu();
$MostrarMenu = $Menu->ObtenerMenu();

?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="<?=$baseUrl?>" style="padding: 0px;">
            <img src="<?=Yii::getAlias('@web')?>/images/logo.png" title="<?=Yii::$app->name?>" width="100" class="img-responsive">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <?php
                if(!empty($MostrarMenu)){
                    $Submenu = [];

                    foreach ($MostrarMenu AS $OpcionMenu) {
                        if($OpcionMenu['IdPadre'] == 0){
                            if(isset($Submenu[$OpcionMenu['IdMenu']])){
                                ?>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Dropdown
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                      <a class="dropdown-item" href="#">Action</a>
                                      <a class="dropdown-item" href="#">Another action</a>
                                      <div class="dropdown-divider"></div>
                                      <a class="dropdown-item" href="#">Something else here</a>
                                    </div>
                                </li>
                                <?php
                            }else{
                                ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?=Yii::getAlias('@web').$OpcionMenu['Url']?>">
                                        <?=$OpcionMenu['Nombre']?>
                                    </a>
                                </li>
                                <?php
                            }                        
                        }else{
                            $Submenu[$OpcionMenu['IdPadre']] = $OpcionMenu;
                        }                  
                    }
                }
                ?>
                <!--<li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Link</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Dropdown
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="#">Disabled</a>
                </li>-->
            </ul>
            <!--<form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>-->
        </div>
    </div>    
</nav>

<input type="hidden" name="urlBase" id="urlBase" value="<?=$baseUrl?>">
<input type="hidden" name="urlWeb" id="urlWeb" value="<?=Yii::getAlias('@web')?>">

<?php echo $this->render('modals.php'); ?>