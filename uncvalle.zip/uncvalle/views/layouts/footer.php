<footer class="footer">
    <div class="container">
        <p class="pull-right">Ing. Miguel Lopez</p>
    </div>
</footer>