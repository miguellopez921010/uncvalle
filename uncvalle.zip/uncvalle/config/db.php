<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=190.8.176.144;dbname=uncvalle_principal',
    'username' => 'uncvalle_root',
    'password' => 'Uncvalle2020',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
